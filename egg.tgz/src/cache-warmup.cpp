// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cache warmup"); }
int main(){
  announce();
  return lionss_run_workload("cache-warmup");
}
