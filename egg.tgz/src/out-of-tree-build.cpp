// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "out of tree build");
  std::fflush(stdout);
  return lionss_run_workload("out-of-tree-build");
}
