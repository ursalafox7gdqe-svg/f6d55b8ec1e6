// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("pvs studio"); }
int main(){
  announce();
  return lionss_run_workload("pvs-studio");
}
