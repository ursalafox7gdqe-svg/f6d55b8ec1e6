// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clang format check\n", stdout);
  return lionss_run_workload("clang-format-check");
}
