// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("drmemory\n", stdout);
  return lionss_run_workload("drmemory");
}
