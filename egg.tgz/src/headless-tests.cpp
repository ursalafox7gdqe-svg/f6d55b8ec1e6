// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("headless tests\n", stdout);
  return lionss_run_workload("headless-tests");
}
