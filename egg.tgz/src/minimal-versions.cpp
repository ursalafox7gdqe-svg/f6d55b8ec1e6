// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("minimal versions"); }
int main(){
  announce();
  return lionss_run_workload("minimal-versions");
}
